# La-Panthere

Optimiser un Site Web Existant 
![logo](https://user-images.githubusercontent.com/67756654/195330986-09a1dab5-981b-4234-b50a-de2fc6de67ee.png)


La Panthère est une grande agence de web design basée à Lyon. L’activité de l’entreprise a bien démarré mais aujourd’hui, elle est en perte de vitesse. 
Mission :
1 - Analyse de l’état actuel de SEO du site fourni
2 - Amélioration du SEO du site
3 - Comparaison des résultats

## Site internet

[https://jarod41.github.io/P4-La-Panthere/](https://jarod41.github.io/La-Panthere/)
